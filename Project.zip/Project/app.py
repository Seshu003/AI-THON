import mongo
import mongo_db
from flask import Flask, render_template, request, jsonify
from pymongo import MongoClient

app = Flask(__name__)

# MongoDB connection URI
mongo_uri = 'mongodb+srv://seshu2005:seshu2005@cluster0.ejnwz3o.mongodb.net/'

@app.route('/')
def pharma():
    return render_template('pharma.html')

@app.route('/create_inventory', methods=['POST'])
def create_inventory():
    # Get data from the HTML form
    name = request.form.get('name')
    quantity = int(request.form.get('quantity'))
    price = float(request.form.get('price'))

    # Connect to MongoDB
    client = MongoClient(mongo_uri)
    db = client.inventorydb
    inventory_collection = db.inventory

    # Create a new inventory item
    new_inventory_item = {
        'name': name,
        'quantity': quantity,
        'price': price
    }

    # Insert the new inventory item into the collection
    inventory_collection.insert_one(new_inventory_item)

    client.close()

    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
