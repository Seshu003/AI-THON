const express = require('express');
const MongoClient = require('mongodb').MongoClient;
const app = express();
const port = 3000;

// MongoDB connection string
const mongoURI = 'mongodb+srv://seshu2005:seshu2005@cluster0.ejnwz3o.mongodb.net/';

app.get('/', (req, res) => {
  // Connect to MongoDB
  MongoClient.connect(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true }, (err, client) => {
    if (err) throw err;

    // Access the database
    const db = client.db('Pharma');

    // Access the collection
    const collection = db.collection('data');

    // Fetch data from MongoDB
    collection.find({}).toArray((err, data) => {
      if (err) throw err;

      // Close the MongoDB connection
      client.close();

      // Render HTML with fetched data
      res.send(renderHTML(data));
    });
  });
});

function renderHTML(data) {
  let html = '<html><head><title>MongoDB Data</title></head><body>';

  // Display data in HTML
  data.forEach(entry => {
//    html += <div><strong>Cause:</strong> ${entry.cause}</div>;
//    html += <div><strong>Symptoms:</strong> ${entry.symptoms}</div>;
//    html += <div><strong>Medication:</strong> ${entry.medication}</div><hr>;
  });

  html += '</body></html>';
  return html;
}

app.listen(port, () => {
  console.log(Server is running on http://localhost:${port});
});